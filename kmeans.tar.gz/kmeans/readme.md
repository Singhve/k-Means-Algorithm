This project includes source files : main.cpp, KMeansClusteringProcessor.h, KMeansClusteringProcessor.cpp.
And datafile and Makefile must be in the same directory with the source files.
You can build the project using Makefile ie run command "make"
Then the executive file mykMeans is generated.
ex. 
make
./mykMeans iris.data.txt 3

